 <div class="wrapper row-offcanvas row-offcanvas-left"> <!----wrapper div start here ---->
            <!-- Left side column. contains the logo and sidebar -->
			
			
			
            <aside class="left-side sidebar-offcanvas">              <!----leftbar start here-->
                <!-- sidebar: style can be found in sidebar.less -->
                <section class="sidebar">
                    <!-- Sidebar user panel -->
                    
                    <!-- search form -->
                   
                    <!-- /.search form -->
                    <!-- sidebar menu: : style can be found in sidebar.less -->
                    <ul class="sidebar-menu">
                        <li class="active">
                            <a href="index.php/admin">
                                <i class="fa fa-dashboard"></i> <span>Dashboard</span>
                            </a>
                        </li>
						
						
	<!--- website  menu start-->
<li class="treeview">
  <a href="javascript:void(0);">
      <i class="fa fa-edit"></i> <span>Web Site Tools</span>
      <i class="fa fa-angle-left pull-right"></i>
  </a>
  <ul class="treeview-menu">
      <li><a href="index.php/website/welcome_message"><i class="fa fa-angle-double-right"></i> Welcome Message</a></li>
      <li><a href="index.php/website/principal_message"><i class="fa fa-angle-double-right"></i> Principal Message</a></li>
      <li><a href="index.php/website/vice_principal_msg"><i class="fa fa-angle-double-right"></i> Vice-principal Message</a></li>
     <li><a href="index.php/website/about"><i class="fa fa-angle-double-right"></i> About</a></li>
                    <li><a href="index.php/website/history"><i class="fa fa-angle-double-right"></i> History</a></li>
     
    <li><a href="index.php/website/rules_regulation"><i class="fa fa-angle-double-right"></i> Rules & Regulation</a></li>
    <li><a href="index.php/website/facility"><i class="fa fa-angle-double-right"></i> Facility</a></li>
    <li><a href="index.php/website/infrastructure"><i class="fa fa-angle-double-right"></i> Infrastructure</a></li>
    
    <li><a href="index.php/website/gallery"><i class="fa fa-angle-double-right"></i> <span>Gallery</span> </a></li>
    <li><a href="index.php/website/syllabus"><i class="fa fa-angle-double-right"></i> <span>syllabus</span> </a></li>
    
    <li><a href="index.php/website/admissionResult"><i class="fa fa-angle-double-right"></i> <span>Admission Result</span> </a></li>

    <li><a href="index.php/website/notice"><i class="fa fa-angle-double-right"></i> <span>Notice</span> </a></li>
    
    <li>
      <a href="index.php/website/department">
        <i class="fa fa-angle-double-right"></i> <span>Department</span> 
      </a>
    </li>

    <li><a href="index.php/slide_settings/slidePreview"><i class="fa fa-angle-double-right"></i>Slide Preview</a></li>
    
                                
                
     <li class="treeview">
                <a href="javascript:void(0);">
                    <i class="glyphicon glyphicon-cog"></i> <span>Settings</span>
                    <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
    
    <li><a href="index.php/website/add_image_catagory"><i class="fa fa-angle-double-right"></i>Create Album</a></li>
    
    <li><a href="index.php/website/add_department"><i class="fa fa-angle-double-right"></i>New Department</a></li>
    <!-- google location -->
    <li><a href="index.php/website/google_map"><i class="fa fa-angle-double-right"></i>School Location</a></li>
    
    <li><a href="index.php/slide_settings/settings"><i class="fa fa-angle-double-right"></i>Slide Upload</a></li>
                </ul>
            </li>
                </ul>
  
            </li>
            <!-- end website -->
						
  <!---Student Section Left bar Start-->            
            <li class="treeview">
                            <a href="javascript:void(0);">
                                <i class="glyphicon glyphicon-user"></i>
                                <span>Student</span>
                                <i class="fa fa-angle-left pull-right"></i>
                
                            </a>
              
                  
                            <ul class="treeview-menu">
                  <li><a href="student_section/student_registration"><i class="fa fa-angle-double-right"></i>Registration</a></li>
                  
                  <li><a href="student_section/student_report"><i class="fa fa-angle-double-right"></i>Student List</a></li>
                  
                  <li><a href="student_section/attendance"><i class="fa fa-angle-double-right"></i>Attendance</a></li>
                  <li><a href="student_section/certificate"><i class="fa fa-angle-double-right"></i>Certificate</a></li>
                  <li><a href="student_section/admission_cancel"><i class="fa fa-angle-double-right"></i>Admission Cencel</a></li>
                  
                            </ul>
                        </li>
<!---Student Section Left bar End-->  

<!--Admission Left Bar Start-->
						<li class="treeview">
                            <a href="javascript:void(0);">
                                <i class="fa fa-book"></i>
                                <span>Admission</span>
                                <i class="fa fa-angle-left pull-right"></i>
                            </a>
                            <ul class="treeview-menu">
                                <li><a href="admission_section/admission"><i class="fa fa-angle-double-right"></i> Application</a></li>
								<li><a href="admission_section/setting"><i class="fa fa-angle-double-right"></i> Setting</a></li>
                            </ul> 
                        </li>

					<!---Admission Left Bar End-->

<!--Class Routine Left Bar Start-->
<li class="treeview">
                            <a href="javascript:void(0);">
                                <i class="fa fa-book"></i>
                                <span>Class Routine</span>
                                <i class="fa fa-angle-left pull-right"></i>
                            </a>
                            <ul class="treeview-menu">
                                <li><a href="class_routine/setting"><i class="fa fa-angle-double-right"></i> Setting</a></li>
                                <li><a href="class_routine/routine"><i class="fa fa-angle-double-right"></i> Routine</a></li>
                            </ul> 
                        </li>

<!---Class Routine Left Bar End-->

<!---Library Section Left Bar Start-->
            <li class="treeview">
                            <a href="javascript:void(0);">
                                <i class="fa fa-book"></i>
                                <span>Library</span>
                                <i class="fa fa-angle-left pull-right"></i>
                            </a>
                            <ul class="treeview-menu">
                              
                                <li><a href="library_section/book_setup"><i class="fa fa-angle-double-right"></i> Book Setup</a></li>
                                <li><a href="library_section/book_edit"><i class="fa fa-angle-double-right"></i> Book Edit</a></li>
                                <li><a href="library_section/book_dist_return"><i class="fa fa-angle-double-right"></i> Book Distribution</a></li>
                                <li><a href="library_section/book_report"><i class="fa fa-angle-double-right"></i>Report</a></li>
                
                
                            </ul>
              
                        </li>

            
<!---Library Section Left Bar End-->
												
						<li class="treeview">
                            <a href="javascript:void(0);">
                                <i class="fa fa-bar-chart-o"></i>
                                <span>Examination</span>
                                <i class="fa fa-angle-left pull-right"></i>
                            </a>
                             <!-- settings menu start -->
                            <ul class="treeview-menu">
    <li><a href="index.php/exam/xmController"><i class="fa fa-angle-double-right"></i>Exam Controller</a></li>
    
    <li><a href="index.php/exam/XmSeat"><i class="fa fa-angle-double-right"></i>Exam Seat</a></li>

	 <li><a href="index.php/exam/paperProcessing"><i class="fa fa-angle-double-right"></i>Exam Paper Processing</a></li>
	 
   <li><a href="index.php/exam/result"><i class="fa fa-angle-double-right"></i>Result Processing</a></li>
  <li>
      <a href="index.php/xmReport/single_marksheet"><i class="fa fa-angle-double-right"></i>Single Marksheet</a>
      <a href="index.php/xmReport/meritListPanel"><i class="fa fa-angle-double-right"></i>Merit List</a>
  </li>
                                    
    

   

   
   <!-- exam controller -->
  
   
   <li class="treeview">
      <a href="javascript:void(0);">
        <i class="glyphicon glyphicon-cog"></i>
        <span>Settings</span>
        <i class="fa fa-angle-left pull-right"></i>
      </a>
      <ul class="treeview-menu">
        <li><a href="index.php/exam/general"><i class="fa fa-angle-double-right"></i>General Settings</a></li>
      </ul>
    </li>
<!-- settings menu end -->
                                 
</ul>
</li>
						
			<li class="treeview">
              <a href="javascript:void(0);">
                <i class="fa fa-bar-chart-o"></i>
                  <span>Account</span>
                  <i class="fa fa-angle-left pull-right"></i>
              </a>					
                
                <ul class="treeview-menu">
							
							 <li><a href="index.php/account/student_payment_form"><i class="fa fa-angle-double-right"></i>Student bill collection</a></li>
							 
							 <li><a href="index.php/account_billgenerate/billpages"><i class="fa fa-angle-double-right"></i>Student Bill Generate</a></li>
               
							 
               <!-- <li> -->
							   <!-- <a href="index.php/account/add_balance"><i class="fa fa-angle-double-right"></i>Balance Add</a> -->
							 <!-- </li> -->

							 <li>
							<a  href = "javascript:void(0);" ><i class="fa fa-angle-double-right"></i>Balance Transfer</a>
							 </li>
							 
							 <!-- href="index.php/account_edit/balance_transper" -->
							 
               <li><a href="index.php/account/income_checksohow"><i class="fa fa-angle-double-right"></i>Income</a></li>
							 
               <li><a href="index.php/account/expanse_form"><i class="fa fa-angle-double-right"></i>Expanse</a></li>
							 
               <li><a href="index.php/account/application_fee_form"><i class="fa fa-angle-double-right"></i>Online Application Fee</a></li>

               <li><a href="index.php/account/advancePayment"><i class="fa fa-angle-double-right"></i>Advance Payment</a></li>

              

							<!-- <li><a href="index.php/account/cash_application_fee"><i class="fa fa-angle-double-right"></i>Cash Application Fee</a></li>-->
							 <li><a href="index.php/account/stu_scholarship"><i class="fa fa-angle-double-right"></i>ADD Scholarship</a></li>
							  <li class="treeview">
								<a href="javascript:void(0);">
									<i class="glyphicon glyphicon-info-sign"></i> <span>Reporting</span>
									<i class="fa fa-angle-left pull-right"></i>
								</a>
								<ul class="treeview-menu">
							
							 <li><a href="index.php/account_edit/listof_main_ledger"><i class="fa fa-angle-double-right"></i>General Ledger</a></li>
							 
               <li><a href="index.php/accountReport/studentLedger"><i class="fa fa-angle-double-right"></i>Student Ledger</a></li>

               <li><a href="accountReport/monthlyIncomeReport" target="_blank" ><i class="fa fa-angle-double-right" ></i>Monthly Income Statement</a></li>

               <li><a href="index.php/accountReport/monthlyExpanseStatement" target="_blank" ><i class="fa fa-angle-double-right"></i>Monthly Expanse Statement</a></li>

               <li><a href="index.php/accountReport/advancedPaymentReport" ><i class="fa fa-angle-double-right"></i>Advanced Payment</a></li>

               </ul>
							 </li>

               <li class="treeview">
                <a href="javascript:void(0);">
                  <i class="glyphicon glyphicon-cog"></i> <span>Settings</span>
                  <i class="fa fa-angle-left pull-right"></i>
                </a>
                
                <ul class="treeview-menu">
                  
                  <li><a href="index.php/account/student_fee_catg"><i class="fa fa-angle-double-right"></i>General Setting</a></li>
                  
                  <li><a href="index.php/account/class_fee_sett"><i class="fa fa-angle-double-right"></i>Class Fee Setting</a></li>

                   <li><a href="index.php/account/account_open"><i class="fa fa-angle-double-right"></i>Account Open</a></li>
                  
                </ul>
                
              </li>
            </ul>
          </li>
						
<!---Employee Section Left Bar Start-->
  
        <li class="treeview">
                            <a href="javascript:void(0);">
                                <i class="glyphicon glyphicon-user"></i>
                                <span>Employee</span>
                                <i class="fa fa-angle-left pull-right"></i>
                            </a>
                            <ul class="treeview-menu">
                               <li><a href="index.php/employee_section/setting"><i class="fa fa-angle-double-right"></i>Setting</a></li> 
                
                
                                <li><a href="index.php/employee_section/employee_registration"><i class="fa fa-angle-double-right"></i>Registration</a></li>
                          
                <li><a href="index.php/employee_section/employee_rqst_leave_form"><i class="fa fa-angle-double-right"></i>Leave Request </a></li>
                
                <!---<li><a href="index.php/employee_section/employee_salary_history"><i class="fa fa-angle-double-right"></i>Employee Salary</a></li>-->
                
                <li><a href="index.php/employee_section/employee_vacancy"><i class="fa fa-angle-double-right"></i>Vacancy </a></li>
                  <li><a href="index.php/employee_section/employee_attendence"><i class="fa fa-angle-double-right"></i>Attendance </a></li>
                
                            </ul>
                 </li>


          
<!--Employee Section Left Bar End-->
 
<li><a href="index.php/accountReport/vahicleStdAssign" ><i class="fa fa-car"></i>Transport Management</a></li>

<!---User  Section Left Bar End-->	
						<li class="treeview">
                            <a href="javascript:void(0);">
                                <i class="fa fa-bar-chart-o"></i>
                                <span>User Panel</span>
                                <i class="fa fa-angle-left pull-right"></i>
                            </a>
                            <ul class="treeview-menu">
                               <li><a href="index.php/userpanel/user_registations"><i class="fa fa-angle-double-right"></i> User Registration</a></li>
							   <li><a href="index.php/userpanel/show_registation"><i class="fa fa-angle-double-right"></i>User List</a></li>
                                
                            </ul>
                        </li>
						
				
                       <li><a href="index.php/account/smsportal"><i class="fa fa-angle-double-right"></i>SMS Portal</a></li>
                          
						
     <!---basic setting start-->           
            <li class="treeview">
                            <a href="javascript:void(0);">
                                <i class="fa fa-bar-chart-o"></i>
                                <span>Setting</span>
                                <i class="fa fa-angle-left pull-right"></i>
                            </a>
                            <ul class="treeview-menu">
                              
                                <li><a href="basic_setting/setting"><i class="glyphicon glyphicon-cog"></i> Initial Setting </a></li>
                                <li><a href="index.php/userpanel/school_profile"><i class="fa fa-angle-double-right"></i>School Profile</a></li>
                               <li><a href="index.php/userpanel/school_commitee"><i class="fa fa-angle-double-right"></i>School Commitee</a></li>
                               
                            </ul>
                        </li>
<!---basic setting end-->                   
                       
						<!--
                        <li>
                            <a href="index.php/admin/calendar">
                                <i class="fa fa-calendar"></i> <span>Calendar</span>
                                <small class="badge pull-right bg-red">3</small>
                            </a>
                        </li>
                        -->
                        
                    </ul>
                </section>
                <!-- /.sidebar -->
            </aside>  
			