<?php

$connect=mysql_connect("localhost","root","")or die('server not found');
mysql_select_db('school_admin')or die('database not found');

?>