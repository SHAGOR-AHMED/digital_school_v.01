<aside class="right-side">      <!---rightbar start here --->
                <!-- Content Header (Page header) -->
				
                <section class="content-header">
                    <h1>
                        ADD Vacancy
                        <small>Control panel</small>
                    </h1>
                    <ol class="breadcrumb">
                        <li><a href="javascript:void(0);"><i class="fa fa-dashboard"></i> Home</a></li>
                        <li class="active">Dashboard</li>
                    </ol>
                </section>

                <!-- Main content -->
                <section class="content">
					<div class="container-fluid">
                    <div class="row">
                       <div class="col-md-10">
							
						<form  class="form-horizontal" role="form" action="index.php/admin/re_admission" method="post" enctype="multipart/form-data">

						
						  <div class="form-group">
							<label class="control-label col-sm-3" class="col-md-3" for="email">Designation</label>
							<div class="col-sm-3" class="col-md-3">
							  <input type="name" class="form-control" id="name" placeholder="Enter Designation" onkeypress=""/>
							</div>
							<label class="control-label col-sm-3" class="col-md-3" for="pwd">Total Teacher</label>
								<div class="col-sm-3" class="col-md-3"> 
								  <input type="name" class="form-control" id="name" placeholder="Enter Designation" onkeypress=""/>
								</div>
						  </div>
						  
							<div class="form-group">
								<label class="control-label col-sm-3" class="col-md-3" for="email">Vacancy</label>
								<div class="col-sm-3" class="col-md-3">
								  <input type="email" name="email" class="form-control" id="email" placeholder="Session Year">
								</div>
								<label class="control-label col-sm-3" class="col-md-3" for="email">Present Teacher</label>
								<div class="col-sm-3" class="col-md-3">
								  <input type="email" name="email" class="form-control" id="email" placeholder="Enter Course Fee" onkeypress="">
								</div>
							</div>
							
							
						  <div class="form-group"> 
							<div class="col-sm-offset-2 col-sm-2 col-md-2">
							</div>
							<div class="col-sm-offset-2 col-sm-10 col-md-10">
							  <button type="submit" class="btn btn-primary" name="submit" id="submit"><span class="glyphicon glyphicon-send"></span> Submit</button> &nbsp;&nbsp;&nbsp;
							  <button type="reset" class="btn btn-warning"><span class="glyphicon glyphicon-refresh"></span> Reset</button>
							</div>
						  </div>
						</form>

							
						
					  </div>
					  <div class="col-md-2">
					  
					  </div>
                    </div>
					</div>

                </section><!-- /.content -->
            </aside><!-- /.right-side -->     <!---rightbar close here ---->