<?php

$sql = mysql_query("UPDATE about SET lastname='Doe' WHERE id='$id'");


?>