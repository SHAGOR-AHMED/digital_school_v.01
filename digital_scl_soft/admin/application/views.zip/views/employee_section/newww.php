<div class="box">
 <div class="box-body">

   <ul class="nav nav-tabs" id="myTab">
			<li class="active"><a data-toggle="tab" href="#emp_attendance" style="font-weight:bold;">Employee Attendance</a></li>
			
			<li><a data-toggle="tab" href="#attendance_report" style="font-weight:bold;" >Attendance Report</a></li>
   </ul>
                      <?php 
						//$this->load->view("employee_section/success");
					   ?>
        <div class="tab-content">
				<div id="emp_attendance" class="tab-pane fade in active">
					  <div class="row" style="margin-top:40px;">
						  <div class="table-responsive">
								<div class="col-md-12">
										
								</div>
						  </div>
					  </div>
				</div>
				
				<div id="attendance_report" class="tab-pane fade">
					 <div class="row" style="margin-top:40px;">
						  <div class="table-responsive">
								<div class="col-md-12">
											
								</div>
						  </div>
					 </div>
				</div>
        </div>
</div>

</div>
					  


