<?php
	function hello(){

	}

/**
* 
*/
class ClassName extends AnotherClass
{
	
	function __construct(argument)
	{
		# code...
	}
}

	find_use(f10);
?>